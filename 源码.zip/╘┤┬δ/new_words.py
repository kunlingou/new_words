# coding:UTF-8

import jieba
import jieba.analyse
import csv
import re


# 分词工具(以一个句子为单元)
def cut_news(file):  # file=news_all.txt
    print('running...')
    for lines in open(file, encoding='utf-8'):
        strip_chars = '？。！'
        single_line = lines.translate(str.maketrans(dict.fromkeys(strip_chars, '#')))
        lines = single_line.split('#')
        # print(lines)
        for line in lines:
            list_news = []
            if len(line) > 1:
                line = ' '.join(jieba.cut(line, cut_all=True))
                list_news.append(line)
            # print(u"[全模式]: ", "/ ".join(list_news))
            yield list_news


# 导出结果到txt文件
def news_cut_into_file(list_news, file3):
    with open(file3, 'a', encoding='utf-8') as f3:
        for line in list_news:
            print("/ ".join(line))
            f3.writelines(line)


# 导出结果到csv文件
def output_csvfile(list_news6, file3):
    with open(file3, 'a', encoding="gb18030", newline='') as csvfile:  # newline=''解决空行问题
        spamwriter = csv.writer(csvfile, dialect='excel')
        title = ['标注单元', '主体', '主体关键字', '维度', '维度关键字', '分词']
        spamwriter.writerow(title)
        i = 0
        mainclasses = ['肯德基', '麦当劳', '汉堡王', '德克士']
        kindclasses = [['产品品类', '珍虾厚牛堡', '柠香鸡腿堡', '蛋堡', '法棍汉堡', '左将军鸡腿酥皮卷', '蛋包饭', '椰香咖喱', '脆皮霸王翅', '奥尔良鸡翅', '潮汕粥', '干贝大虾粥', '川府辛香肉酱大薯', '肉酱薯', '咸蛋黄肉粽', '奇乐圈', '菜丝色拉', '冰淇淋花筒', '雪冰', '马卡龙', '芒果千层蛋糕', '水果挞', '莲子挞', '葡式挞', '红豆挞', '吃过瘾炸鸡桶', '万事OK明星餐', '摩卡', '拿铁', '苹果风味茶', '特饮', '鲜萃茶', '法风烧饼'],
                       ['制作食材', '麦香鱼', '鳕鱼', '伴虾', '半虾', '左宗棠鸡', '猪肉', '红肠', '腊肠', '烤猪', '上等肥牛', '牛肉饼', '朝天椒', '二荆条', '小米椒', '鸡柳蛋', '蒸蛋', '蛋包', '中国东北小麦粉', '泰国木薯淀粉', '南洋酱', '塔塔酱', '甜辣酱', '红柚', '冲绳海盐', '植物起酥油', '人造黄油'],
                       ['活动', '哆啦A梦', '王者荣耀', '鹿晗', '吴亦凡', '机器人店员', '定制歌单', '海绵宝宝', '章鱼哥', '派大星', '9爱耍大排', '午后芋见柠', '我爱吃鸡', '麻辣川香根根燃魂', '木偶奇遇记', '小布头奇遇记', '阅读桶', '天使餐厅', '曙光基金', '粉丝王国', '麦麦童乐会', '生日会'],
                       ['促销', '加价', '加一元', '加1元', '加3元', '首单送辣翅', '39元过瘾开吃', '团购', '团享', '特价', '特惠', '新用户红包', '新用户优惠', '七夕早餐', '爱的全餐', '吃过瘾炸鸡桶', '一桶都是腿', '咖啡买一送一', '会员凭券']]
        for line6 in list_news6:
            i += 1
            text = " ".join(line6)
            mainclassbuffer = []
            for mainclass in mainclasses:
                if re.search(mainclass, text, re.I | re.S):
                    mainclassbuffer.append(mainclass)
            line4buffer = []
            line5buffer = []
            for kindclass in kindclasses:
                i0 = 0
                line4 = ''
                isfind = 0  # 是否存在匹配项
                for line5 in kindclass:
                    if i0 == 0:
                        line4 = line5
                    elif re.search(line5, text, re.I | re.S):
                        line5buffer.append(line5)
                        line4buffer.append(line4)
                        isfind = 1
                    i0 += 1
                # if isfind == 1:
                #     line4buffer += (line4+' ')
            if mainclassbuffer != '' and line4buffer != '':
                for mainclassbuffer0 in mainclassbuffer:
                    i1 = 0
                    for line4buffer0 in line4buffer:
                        spamwriter.writerow([i, mainclassbuffer0, mainclassbuffer0, line4buffer0, line5buffer[i1], text])
                        i1 += 1
        # i = 0
        # for line5 in list_news5:
        #     j = 0
        #     for line4 in list_news4:
        #         if i == j:
        #             spamwriter.writerow(['', '', '', " ".join(line4), '', " ".join(line5)])
        #         elif i < j:
        #             break
        #         j += 1
        #     i += 1
        #     if i == 10:
        #         break


# 提取关键字（按频率）
def get_mainnews(file):  # file=news_all.txt

    print('running...')
    for line in open(file, encoding='utf-8'):
        list_news = []
        if len(line) > 1:
            line = ' '.join(jieba.analyse.extract_tags(line, topK=3))   # topK:关键词出现从高到低排序,取前面topK个关键词
            list_news.append(line)
            # print(u"[全模式]: ", "/ ".join(list_news))
        yield list_news


if __name__ == '__main__':
    # 0.添加自定义词典、停用词典
    jieba.load_userdict("userdict.txt")  # file_name为自定义词典的路径(关键字)
    jieba.analyse.set_stop_words("stop_words.txt")  # 停用词库，去除停用词（从txt中去掉不必要的词）

    # 存放数组

    # 1.分词
    t = cut_news('news_all.txt')
    # 4.存放csv文件
    output_csvfile(t,  'output.csv')

# # 全模式
# seg_list = jieba.cut(final, cut_all=True)
# print(u"[全模式]: ", "/ ".join(seg_list))
#
# # 3.关键词提取
# tags = jieba.analyse.extract_tags(text, topK=10)  # topK:关键词出现从高到低排序,取前面topK个关键词
# print(u"[全模式]: ", "/ ".join(tags))
